document.addEventListener("DOMContentLoaded", () => {
});
//accordeon
var accordeonButtons = document.getElementsByClassName("accordeon__button");

//пишем событие при клике на кнопки - вызов функции toggle
for(var i = 0; i < accordeonButtons.length; i++) {
    var accordeonButton = accordeonButtons[i];

    accordeonButton.addEventListener("click", toggleItems, false);
}

//пишем функцию
function toggleItems() {

    // переменная кнопки(актульная) с классом
    var itemClass = this.className;

    // добавляем всем кнопкам класс close
    for(var i = 0; i < accordeonButtons.length; i++) {
        accordeonButtons[i].className = "accordeon__button closed";
    }

    // закрываем все открытые панели с текстом
    var pannels = document.getElementsByClassName("accordeon__panel");
    for (var z = 0; z < pannels.length; z++) {
        pannels[z].style.maxHeight = 0;
    }

    // проверка. если кнопка имеет класс close при нажатии
    // к актуальной(нажатой) кнопке добававляем активный класс
    // а панели - которая находится рядом задаем высоту
    if(itemClass == "accordeon__button closed") {
        this.className = "accordeon__button active";
        var panel = this.nextElementSibling;
        panel.style.maxHeight = panel.scrollHeight + "px";
    }

}
//popup
let popupBg = document.querySelector('.popup__bg');
let popup = document.querySelector('.popup');
let openPopupButtons = document.querySelectorAll('.open-popup');
let closePopupButton = document.querySelector('.close-popup');

openPopupButtons.forEach((button) => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        popupBg.classList.add('active');
        popup.classList.add('active');
    })
});

closePopupButton.addEventListener('click',() => {
    popupBg.classList.remove('active');
    popup.classList.remove('active');
});

document.addEventListener('click', (e) => {
    if(e.target === popupBg) {
        popupBg.classList.remove('active');
        popup.classList.remove('active');
    }
});
let popupBg2 = document.querySelector('.popup__bg2');
let popup2 = document.querySelector('.popup2');
let openPopupButtons2 = document.querySelectorAll('.open-popup2');
let closePopupButton2 = document.querySelector('.close-popup2');

openPopupButtons2.forEach((button) => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        popupBg2.classList.add('active');
        popup2.classList.add('active');
    })
});

closePopupButton2.addEventListener('click',() => {
    popupBg2.classList.remove('active');
    popup2.classList.remove('active');
});

document.addEventListener('click', (e) => {
    if(e.target === popupBg2) {
        popupBg2.classList.remove('active');
        popup2.classList.remove('active');
    }
});

let popupBg3 = document.querySelector('.popup__bg3');
let popup3 = document.querySelector('.popup3');
let openPopupButtons3 = document.querySelectorAll('.open-popup3');
let closePopupButton3 = document.querySelector('.close-popup3');

openPopupButtons3.forEach((button) => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        popupBg3.classList.add('active');
        popup3.classList.add('active');
    })
});

closePopupButton3.addEventListener('click',() => {
    popupBg3.classList.remove('active');
    popup3.classList.remove('active');
});

document.addEventListener('click', (e) => {
    if(e.target === popupBg3) {
        popupBg3.classList.remove('active');
        popup3.classList.remove('active');
    }
});

let popupBg4 = document.querySelector('.popup__bg4');
let popup4 = document.querySelector('.popup4');
let openPopupButtons4 = document.querySelectorAll('.open-popup4');
let closePopupButton4 = document.querySelector('.close-popup4');

openPopupButtons4.forEach((button) => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        popupBg4.classList.add('active');
        popup4.classList.add('active');
    })
});

closePopupButton4.addEventListener('click',() => {
    popupBg4.classList.remove('active');
    popup4.classList.remove('active');
});

document.addEventListener('click', (e) => {
    if(e.target === popupBg4) {
        popupBg4.classList.remove('active');
        popup4.classList.remove('active');
    }
});

let popupBg5 = document.querySelector('.popup__bg5');
let popup5 = document.querySelector('.popup5');
let openPopupButtons5 = document.querySelectorAll('.open-popup5');
let closePopupButton5 = document.querySelector('.close-popup5');

openPopupButtons5.forEach((button) => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        popupBg5.classList.add('active');
        popup5.classList.add('active');
    })
});

closePopupButton5.addEventListener('click',() => {
    popupBg5.classList.remove('active');
    popup5.classList.remove('active');
});

document.addEventListener('click', (e) => {
    if(e.target === popupBg5) {
        popupBg5.classList.remove('active');
        popup5.classList.remove('active');
    }
});